<?php
include("studentNav.html");
?>
<!DOCTYPE html>
<html>

<head>
    <title>مـُـلهـِم</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <link rel="stylesheet" href="assets/css/style.css">
  
   

</head>

<body>
   
    <br><br><br>

    <!--second part  -->


    <section class="container">

        <p style='font-size: 30px;font-weight: normal; font-family: Arial, sans-serif; color:#4C4B4B'>Recorded Math Sessions
            <a href="#" style='font-size: 10px; color:rgba(194, 63, 63, 0.83);font-weight: normal; font-family: Arial, sans-serif; color:#4C4B4B'>View All</a></p>

        <br>

        <div class="box-paginacao">

            <input type="radio" name="input-paginacao" id="paginacao1" checked>
            <input type="radio" name="input-paginacao" id="paginacao2">
            <input type="radio" name="input-paginacao" id="paginacao3">
            <input type="radio" name="input-paginacao" id="paginacao4">

            <div class="box-vitrines">
                <ul>

                    <div class="vitrine1">

                        <li><br>&emsp;

                            <i class='fas fa-user-circle' style='font-size:40px;color:#4C4B4B'>
                            <lable style='font-size:20px; font-family: Arial,sans-serif; font-weight: normal;color:rgba(194, 63, 63, 0.83)'>&nbsp;&nbsp;r</lable>
                        </i>

                            <lable style='font-size:10px;color:#65B7A9'><br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Math</lable>
                            <lable style='font-size:10px;color:#4C4B4B'><br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;date&emsp;&emsp;&emsp;&emsp;hours</lable>
                        </li>

                        <li>Vitrine</li>
                        <li>Vitrine</li>

                    </div>

                    <div class="vitrine2">

                        <li>Vitrine</li>
                        <li>Vitrine</li>
                        <li>Vitrine</li>

                    </div>
                    <div class="vitrine3">

                        <li>Vitrine</li>
                        <li>Vitrine</li>
                        <li>Vitrine</li>

                    </div>
                </ul>
                <div class="btn-paginacao">
                    <ul>
                        <li><label for="paginacao1">1</label></li>
                        <li><label for="paginacao2">2</label></li>
                        <li><label for="paginacao3">3</label></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>


</body>

</html>