<?php

require_once('conn.php');

//--------------------- Create Session table, and check if table created ---------------------//

$sql = "CREATE TABLE Session_DB (
sessionID INT(10) UNSIGNED PRIMARY KEY,
time DATE NOT NULL,
history VARCHAR(50))";

if($conn->query($sql)===True){
  echo"Table Session_DB created successfully";
}else{
  echo"error".$conn->error;
}
//--------------------- End Create Session Table ---------------------//

$conn->close();
?>