<?php
require_once('conn.php');
$fname = $_POST['uname'];
$pass = $_POST['psw'];
$gender = $_POST['gender'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$description=$_POST['tutordescription'];
$video= $_POST['video'];
$qualificate=$_POST['qualificate'];

$sql = "INSERT INTO Tutor_DB (phoneNo, first_name,password, tutor_email, gender, Qualification,description,video
)

 VALUES ('$phone','$fname', '$pass', '$email','$gender','$qualificate','$description','$video')";


if ($conn->query($sql) === TRUE) {
  //echo '<script language="javascript">';
  //echo 'alert("Hi! <br>Welcom to Mulhem")';
  //echo '</script>';
  include 'addSchedule.html';

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
//--------------------- End Create Tutor Recored ---------------------//