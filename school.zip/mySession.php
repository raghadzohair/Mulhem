<?php
require_once('conn.php');
$query="select * from scheduleinfo_db order by id desc";
$result=mysqli_query($conn,$query);
?>
<!DOCTYPE html>
<html>

<head>
    <title>مـُـلهـِم</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <link rel="stylesheet" href="assets/css/style.css">


</head>

<body>

    <nav class="header">

        <ul>
            <li><a herf="#"><i  class="fa fa-user-circle" 
            style="font-size: 60px; color: #4c4b4c; margin-top: -24px;
                "></i></a>
                <ul>
                    <li>
                        <li><a href="acountSesttings.html">My Session</a></li>

                        <li><a herf="welcome.html">SignOut</a></li>
                </ul>
                </li>
                <li><a herf="#"><i class="far fa-calendar-alt" style=
                "font-size: 23px; color:#4C4B4B;"></i></a></li>
                <li><a herf="#"><i class="fas fa-comments" style="font-size: 23px;
                color: #4c4b4c; "></i></a></li>
                <li><a herf="#"><i class="fas fa-heart" style="font-size: 23px; color: #4c4b4c; "></i></a></li>
        </ul>
        <ul style="float: right;">
            <li><a href="mySession.php">My Session</a></li>
            <li><a herf="#">History</a></li>
            <li><a href="tutor.php">Tutors</a></li>
            <li>
                <a herf="welcome.html" style="margin-top: -50px;"><img src="assets/img/logo.jpeg" alt="computer" width="100" height="80"></a>
            </li>

        </ul>

    </nav>
    <br><br><br><br><br><br>
    <div class="myDiv2">
        <br>
        <h2 align="center">Check Your Sessions!<br></h2>
        <br>
        <?php 
        while ($rows=$result->fetch_assoc()) {
        ?>
        <button class="accordion"><?php echo $rows["subject_name"] ?></button>
        <div class="panel">
            <p><br>Session with the student ....... in date  <?php echo $rows['date'] ?> <br>Start at <?php echo $rows['time'] ?><br>End at <?php echo $rows['end_time'] ?><br> Duration is 50 minutes </p>
            <div style="margin-top:10px; text-align:center">
                <a class="btn" href="./tutormeetingjoin.php?id=<?php echo $rows['id'] ?>" target="blank" style="margin:auto;display: block;width:60px">Join</a>
            </div>
            
        </div>
        <?php 
        }
        ?>
        <script>
            var acc = document.getElementsByClassName("accordion");
            var i;

            for (i = 0; i < acc.length; i++) {
                acc[i].addEventListener("click", function() {
                    this.classList.toggle("active");
                    var panel = this.nextElementSibling;
                    if (panel.style.display === "block") {
                        panel.style.display = "none";
                    } else {
                        panel.style.display = "block";
                    }
                });
            }
        </script>
</body>

</html>