<?php
require_once('conn.php');

$query="select * from tutor_db";
$query2="select * from scheduleinfo_db where= tutorPhone ='0596090098'" ;
$result2=mysqli_query($conn,$query2);
$result=mysqli_query($conn,$query);
?>
<!DOCTYPE html>
<html>

<head>
  <title>مـُـلهـِم</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

  <style>
    *{
        margin: 0;
        padding: 0;
    }
    nav{
        width: 100%;
        height: 60px;
        background-color: white;
    }
    nav  ul{
        float: left;

    }
    nav ul li {
float: left;
list-style: none;
position: relative;

    }
    nav ul li a {
        display: block;
        font-family: Arial, sans-serif;
        color: #4C4B4B;
        font-size: 17px;
        padding: 24px 14px;
        text-decoration: none;

    }
    nav ul li a:hover {
      background-color:rgba(194, 63, 63, 0.60); 
      color: white;
      border-radius: 20px; 
      
      
    
    }
    nav ul li ul  {
        display: none;
        position: absolute;
        background-color: white;
        padding: 10px;
        box-shadow: 0 6px 14px 0 rgba(0, 0, 0, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.19);
        border-radius: 20px 20px 20px 20px;

    }
    nav ul li:hover ul  {
        display: block;

    }
    nav ul li ul li  {
     width: 180px;
     border-radius: 20px;

    }
    nav ul li ul li a  {
       padding: 8px 14px;

    }
    nav ul li ul li a:hover  {
      background-color:rgba(194, 63, 63, 0.60); 
       border-radius: 20px;


    }
    .header {

position: fixed;
right: 0;
left: 0;
top: 0;

z-index: 1030;
background-color: white;

border: 01;
-webkit-transition: all .5s ease;
transition: all .5s ease;
border-bottom: 2px solid rgba(0, 0, 0, 0.1);
box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.01);


}
.searchButton {
    box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.01);

top: -110px;
margin: auto;
position: relative;
width: 450px;
height: 42px;
border: 2px solid rgba(129, 126, 126, 0.1);
background-color: rgba(129, 126, 126, 0.1);
padding: 0px 10px;
border-radius: 50px;
}

.elementContainer2 {
width: 100%;
height: 70%;
vertical-align: middle;


}

.search {
/*border: none;*/

border-color: seashell;
width: 100%;
height: 100%;
padding: 0px 10px;
border-radius: 50px;
font-size: 18px;
font-family: "Arial, sans-serif";
color: #424242;
font-weight: 500;
}

.search:focus {
outline: none;
}
/*end style for search button */
/*start style for popUp window  */
.popup{
display: none;
width: 100%;
height: 100%;
position: absolute;
top: 0;

justify-content: center;
text-align: center;
align-items: center;


}
.popup-content {
height: 470px;
width: 270px;
background:white;
padding: 20px;
border-radius: 20px;
position: relative;

margin-top: 78px;
box-shadow: 0 6px 14px 0 rgba(153, 197, 231, 0.507), 0 5px 19px 0 rgba(70, 86, 100, 0.507);

}

#close{
position: absolute;
top: -1px;
left: -7px;
height: 20px;
width: 29px;
border-radius: 50px;
cursor: pointer;


}
.videoDiv{
  box-shadow: 0 6px 14px 0 rgba(153, 197, 231, 0.507), 0 5px 19px 0 rgba(70, 86, 100, 0.507);
background-color: white;
margin-top:70px;
border-radius: 20px;
padding: 60px 14px;
}



 /*end style for popUp window  */

 /* prof*/
 *,
    ul {
      margin: 100;
      /*هنا لو حطيناه صفر حتزبط المربعات لكن تخرب بعض المقاسات*/
      padding: 0;
      list-style: none;
    }

    .container {
      width: 1000px;
      height: auto;
      margin: 0 auto;
    }

    .row {
      width: 1000px;
      height: auto;
      margin: 0 auto;
      position: relative;
    }
/*
    input {
      display: none;
    }
*/
    .box-paginacao {
      width: 100%;
      height: auto;
      float: left;
    }

    .box-paginacao h2 {
      /* Tutors*/
      width: 100%;
      height: auto;
      float: left;
      margin: 0 0 50px;
      text-align: left;
      font-family: Arial, sans-serif;
      font-weight: 400;
      font-size: 1.3em;
      color: #4C4B4B;
    }

    .box-paginacao .box-vitrines {
      width: 100%;
      height: 340px;
      float: left;
      overflow: hidden;
      position: relative;
    }

    .box-paginacao ul {
      width: 100%;
      height: auto;
      float: left;
    }

    .box-paginacao ul li {
      width: 250px;
      height: 150px;
      float: left;
      margin: 0 0 10px 60px;
      border: 1px;
      border-radius: 30px;
      text-align: left;
      font-family: Arial, sans-serif;
      color: #4C4B4B;
      box-shadow: 0 1px 5px 0 rgba(59, 49, 49, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.01);
    }

    .box-paginacao .vitrine1,
    .box-paginacao .vitrine2,
    .box-paginacao .vitrine3,
    .box-paginacao .vitrine4 {
      width: 100%;
      height: 336px;
      float: left;
      margin-bottom: 33px;
    }

    .btn-paginacao {
      /*باك قراون ورى الازرار*/
      width: 100%;
      height: auto;
      float: left;
      margin-top: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: absolute;

      left: 0;
      bottom: 0;
      
    }

    .btn-paginacao ul {
      width: auto;
      height: auto;
    }

    .btn-paginacao ul li {
      width: 30px;
      height: 30px;
      float: left;
      margin: 0 5px 0 0;
      border: 0;
    }

    .btn-paginacao ul li:last-child {
      margin: 0;
    }

    .btn-paginacao ul li label {
      /*الازرار*/
      width: 100%;
      height: 30px;
      float: left;
      text-align: center;
      line-height: 30px;
      font-family: Arial, sans-serif;
      font-weight: 400;
      font-size: 1em;
      color: #4C4B4B;
      cursor: pointer;
      border-radius: 50px;
      transition: background-color .25s ease-in-out;
      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.01);
    }

    .btn-paginacao ul li label:hover {
      /* الألوان لما يحط المؤشر*/
      background-color: rgba(194, 63, 63, 0.83);
      color: #F7F4F4;
    }

    #paginacao1:checked~.box-vitrines>ul {
      transition: transform .7s ease-in-out;
      transform: translateY(0px);
    }

    #paginacao1:checked~.box-vitrines label[for="paginacao1"] {
      background-color: rgba(194, 63, 63, 0.83);
      color: #F7F4F4;
    }

    #paginacao2:checked~.box-vitrines>ul {
      transition: transform .7s ease-in-out;
      transform: translateY(-369px);
    }

    #paginacao2:checked~.box-vitrines label[for="paginacao2"] {
      background-color: rgba(194, 63, 63, 0.83);
      color: #F7F4F4;
    }

    #paginacao3:checked~.box-vitrines>ul {
      transition: transform .7s ease-in-out;
      transform: translateY(-738px);
    }

    #paginacao3:checked~.box-vitrines label[for="paginacao3"] {
      background-color: rgba(194, 63, 63, 0.83);
      color: #F7F4F4;
    }

    #paginacao4:checked~.box-vitrines>ul {
      transition: transform .7s ease-in-out;
      transform: translateY(-1107px);
    }

    #paginacao4:checked~.box-vitrines label[for="paginacao4"] {
      background-color: rgba(194, 63, 63, 0.83);
      color: #F7F4F4;
    }

    .checked {
      color: orange;
    }

    /* end prof*/
  </style>

</head>

<body>
 
<nav class="header">

<ul>
    <li><a herf="#"  ><i  class="fa fa-user-circle" 
    style="font-size: 60px; color: #4c4b4c; margin-top: -24px;
        "></i></a>
    <ul>
        <li><li><a href="acountSesttings.html">My Session</a></li>
          
         <li><a herf="welcome.html">SignOut</a></li>
    </ul>
    </li>
    <li><a herf="#"><i class="far fa-calendar-alt" style=
        "font-size: 23px; color:#4C4B4B;"></i></a></li>
    <li><a herf="#"><i class="fas fa-comments" style="font-size: 23px;
        color: #4c4b4c; "></i></a></li>
    <li><a herf="#"><i class="fas fa-heart" style="font-size: 23px; color: #4c4b4c; "></i></a></li>
</ul>
<ul style="float: right;">
    <li><a href="mySession.php">My Session</a></li>
    <li><a herf="#">History</a></li>
    <li><a herf="#">Tutors</a></li>
    <li><a herf="welcome.html" style="margin-top: -50px;"><img src="assets/img/logo.jpeg" alt="computer" width="100"
        height="80"></a></li>

</ul>

</nav>

<br><br><br><br><br><br><br><br>
  <div class="searchButton" style="margin-top: 60px;">

    <table class="elementContainer2">
      <tr>
        <td>
          <input class="search" type="text" placeholder="Search">

        </td>
        <td>

          <a href="#"><i class="fa fa-search"></i></a>
        </td>
      </tr>

    </table>
  </div>
  
  
<!--second part  -->

<section class="container">

    <p style='font-size: 30px;font-weight: normal; font-family: Arial, sans-serif; color:#4C4B4B'>Mathematics Tutors
      
    </p>

    <br>

    <div class="box-paginacao">

      <input style="display: none;" type="radio" name="input-paginacao" id="paginacao1" checked>
      <input style="display: none;"type="radio" name="input-paginacao" id="paginacao2">
      <input style="display: none;" type="radio" name="input-paginacao" id="paginacao3">
      <input style="display: none;" type="radio" name="input-paginacao" id="paginacao4">

      <div class="box-vitrines">
        <ul>

          <div class="vitrine1">
            
            <?php

            while ($rows=$result->fetch_assoc())
           {
             ?>
           <li><br>&emsp;

           <i class='fas fa-user-circle' style='font-size:40px;color:#4C4B4B'>
              <lable id="name"
                style='font-size:20px; font-family: Arial,sans-serif; font-weight: normal;color:rgba(194, 63, 63, 0.83)'>
                &nbsp;&nbsp;<?php 
                echo $rows['first_name'];?></lable>
            </i>    
            
            <br>&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
              <lable style='font-size:10px;color:#4C4B4B'>
                <span class='fa fa-star checked'></span>
                <span class='fa fa-star checked'></span>
                <span class='fa fa-star checke'></span>
                <span class='fa fa-star'></span>
                <span class='fa fa-star'></span>
          </lable>
          <?php
               echo" <lable style='font-size:10px;color:#65B7A9'><br>&emsp;Math</lable>
                  <p id='des' style='font-size:10px;color:#4C4B4B'>&emsp;". $rows['description'].
                   " </p></lable>";
            ?>
            <br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
            <a href="#" id="pop" style='font-size: 10px; color:rgba(194, 63, 63, 0.83);font-weight: normal; font-family: Arial, sans-serif'>more</a>
            
            </li>
              <?php          
           }
           ?>
          </div>

          
        </ul>
        
       <!--<div lass="btn-paginacao">--> 
        <div class="btn-paginacao">
     
          <ul>
            <li><label for="paginacao1">1</label></li>
            <li><label for="paginacao2">2</label></li>
            <li><label for="paginacao3">3</label></li>
          </ul>
        </div>
      </div>
    </div>
  </section>
  

<div class="popup">



  <div class="popup-content">
    <span class="far fa-window-close" id="close"></span>
    <span class="fa fa-user-circle" style="font-size: 60px; float: left; color: #4C4B4B"></span>
    <p style="float: left; color: #4C4B4B; font-family: Arial; margin-top:30px">



    <script>
        document.write(document.getElementById("name").innerHTML);
    </script></p>
  <span class="fas fa-comments" style="float: right;"></span>
  <span class="fas fa-heart" style="float: right;">&ensp; </span>
  <div class="videoDiv">
    
<p>
  vidoe
</p>
  </div>
  <br>
  
  <p style="float: left; color: #4C4B4B; font-family: Arial">
  <script>
  document.write(document.getElementById("des").innerHTML);
  </script></p>
<!---->
<br><br>
<br><br><br>
<hr>
<br>
<p style="float: left; color:rgba(194, 63, 63, 0.83);">Schedule</p>




</div>


</div>
  <script>
    document.getElementById("pop").addEventListener("click",function(){
      document.querySelector(".popup").style.display="flex";
    });

    document.querySelector("#close").addEventListener("click",function(){
      document.querySelector(".popup").style.display="none";
    });
  </script>
  


</body>
</html>