<?php

require_once('conn.php');
//--------------------- Create Mulhem Database and Check if DB Created ---------------------//
/*
$sql = "CREATE DATABASE Mulhem";

if ($conn->query($sql) === TRUE) {
  echo "Database created successfully";
} else {
  echo "Error creating database: " . $conn->error;
}
*///--------------------- End Create Mulhem Database ---------------------//

//--------------------- Create Admin table, and check if table created ---------------------//
/*
$sql = "CREATE TABLE Admin_DB (
ID INT(10) UNSIGNED PRIMARY KEY,
first_name VARCHAR(15) NOT NULL,
last_name VARCHAR(15) NOT NULL,
admin_email VARCHAR(50))";

if($conn->query($sql)===True){
  echo"Table Admin_DB created successfully";
}else{
  echo"error".$conn->error;
}
*///--------------------- End Create Admin Tsble ---------------------//

//--------------------- Create Admin Recored, and check if Recored Created ---------------------//
$sql = "INSERT INTO Admin_DB (ID, first_name, last_name, admin_email)
  VALUES ('$id','$fname', '$lname', '$email')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
//--------------------- End Create Admin Recored ---------------------//

$conn->close();
?>