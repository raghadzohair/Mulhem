<?php
require_once('conn.php');

$query="SELECT * FROM scheduleinfo_db";

$result=mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html>

<head>
  <title>مـُـلهـِم</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

  <link rel="stylesheet" href="assets/css/style.css">


</head>

<body>

  <nav class="header">

    <ul>
      <li><a herf="#"><i class="fa fa-user-circle" style="font-size: 60px; color: #4c4b4c; margin-top: -24px;
        "></i></a>
        <ul>
          <li>
          <li><a href="acountSesttings.html">My Session</a></li>

          <li><a herf="welcome.html">SignOut</a></li>
        </ul>
      </li>
      <li><a herf="#"><i class="far fa-calendar-alt" style="font-size: 23px; color:#4C4B4B;"></i></a></li>
      <li><a herf="#"><i class="fas fa-comments" style="font-size: 23px;
        color: #4c4b4c; "></i></a></li>
      <li><a herf="#"><i class="fas fa-heart" style="font-size: 23px; color: #4c4b4c; "></i></a></li>
    </ul>
    <ul style="float: right;">
      <li><a href="mySession.php">My Session</a></li>
      <li><a herf="#">History</a></li>
      <li><a herf="tutor.php">Tutors</a></li>
      <li><a herf="welcome.html" style="margin-top: -50px;"><img src="assets/img/logo.jpeg" alt="computer" width="100"
            height="80"></a></li>

    </ul>

  </nav>

  <br><br><br><br><br><br><br><br>
  <div class="searchButton" style="margin-top: 60px;">

    <table class="elementContainer2">
      <tr>
        <td>
          <input class="search" type="text" placeholder="Search">

        </td>
        <td>

          <a href="#"><i class="fa fa-search"></i></a>
        </td>
      </tr>

    </table>
  </div>
  <div class="divSchedule">

    <a herf="tutor.php"><span class="far fa-window-close" id="close"
        style="align-items: left; color: #4c4b4c; justify-content: center; text-align: center"></span></a>
    <h2 align="center">Make an Appointment..<br></h2>
    <br>  
    <?php
      while ($rows=$result->fetch_assoc()) {
        ?>
      &emsp;&emsp;&emsp;
      <label>Subject:
        <?php echo $rows['subject_name'];?>
      </label>
      &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
      <label>Date:
        <?php echo $rows['date'];?><br>
      </label>
      &emsp;&emsp;&emsp;
      <label>Start at:
        <?php echo $rows['time'];?>
      </label>
      &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
      <label>End at:
        <?php echo $rows['end_time'];?>
      </label>
      &emsp;&emsp;&emsp;&emsp;

      <a class="btnReservation"  href="./studentmeetingjoin.php?id=<?php echo $rows['id'] ?>" target="blank">Reservation</a>
      <br><br>
    <?php          
      }
      ?>
   
  </div>


</body>

</html>