<?php
require_once('conn.php');

if(!empty($_POST['submit'])){
    $pass = $_POST['psw'];
    $email = $_POST['email'];
    $query = "SELECT * FROM Student_DB  WHERE studnt_email= '$email' and password='$pass'";
    $result = mysqli_query($conn,$query);
    $count = mysqli_num_rows($result);
    if($count>0){
        
        header("Location: tutor.html");
    }
    else{
        echo '<script language="javascript">';
        echo 'alert("Incorrect email or password")';
        echo '</script>';
      
    }
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>مـُـلهـِم</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        .myDiv {

            box-shadow: 0 6px 14px 0 rgba(153, 197, 231, 0.507), 0 5px 19px 0 rgba(70, 86, 100, 0.507);
            text-align: center;
            margin: auto;color: #4C4B4B;


            height: 110px;
            width: 550px;
            

            border: 2px;
            border-radius: 30px;
            padding: 20px;
        }

        .myDiv h2 {
            text-align: left;
            color: #4C4B4B;

            font-size: medium;


        }

        .myDiv2 {

            box-shadow: 0 6px 14px 0 rgba(153, 197, 231, 0.507), 0 5px 19px 0 rgba(70, 86, 100, 0.507);
            text-align: center;
            margin-left: 450px;
            height: 500px;
            width: 550px;
            margin: auto;
            border: 2px;
            border-radius: 30px;
            padding: 20px;
            color: #4C4B4B;

        }

        .p.fieldShape {
            height: 50px;


        }

        .button {
            background-color: rgba(194, 63, 63, 0.83);
            border: none;
            float: left;
            border-radius: 20px;
            padding: 5px 8px;
            text-align: center;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-weight: bold;
            color: #F7F4F4;
            font-size: 16px;
            margin: 80px 20px;
            cursor: pointer;
            box-shadow: 0 6px 14px 0 rgba(0, 0, 0, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.19);
        }
        .button2 {
            background-color: rgba(194, 63, 63, 0.83);
            border: none;
            float: right;
            
            border-radius: 20px;
            padding: 5px 8px;
            text-align: center;
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-weight: bold;
            color: #F7F4F4;
            font-size: 16px;
            margin: 80px -10px;
            cursor: pointer;
            box-shadow: 0 6px 14px 0 rgba(0, 0, 0, 0.2), 0 5px 19px 0 rgba(0, 0, 0, 0.19);
        }
    </style>
</head>

<body>

    <br>
    <div>
        <p style="font-size: 40px; margin:auto; text-align: center; color: #4C4B4B;">
            Welcome back to Mulhem
        </p>
    </div>
    <br><br>

    <div class="myDiv2">
        <h2 align="center">Log in with your email address<br></h2>
        <br>
        <form method="POST" >
            <p>

                <label>Email:&emsp;&emsp;&emsp;&emsp;&emsp;
                    <input name="email" type="text" size="30" style="font-size: 20px;">
                    <br><br>
                </label>

                <label>Password:&emsp;&emsp;&emsp;&ensp;
                    <input name="psw" type="password" size="30" style="font-size: 20px;">
                    <br><br>
                </label>
                <a href="url" style="text-decoration: none">Forget your password?</a>
                &emsp;&emsp;&emsp;&emsp;&emsp;<br>
                <a href="url" style="text-decoration: none">New to Mulhem?</a>
                <a href="signUp.html" style="color:#9e9797;">SignUp</a>&emsp;&emsp;&emsp;&emsp;
            </p>
    
            <input class="button" id = "submit" name="submit" type="submit" value="Log In"/>
           
            <a href="signUp.html" ><button class="button">Cancel</button>
    </a> 
     

    <a href="signUp.html"><button class="button">Get Started</button>
     </a>
    

        <img src="assets/img/pic2.jpg" alt="computer" width="300" height="250" style=" margin-top: -15px; margin-right:-100px;">
        </form>
    </div>
</body>

</html>